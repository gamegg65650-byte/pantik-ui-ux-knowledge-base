# W3C WCAG 2 source files

Copyright © World Wide Web Consortium (W3C). Original files are kept byte for byte. Read the upstream license files and the [W3C Document License](https://www.w3.org/copyright/document-license/) before reusing them.

- [WCAG 2.2 Recommendation (12 December 2024)](https://www.w3.org/TR/2024/REC-WCAG22-20241212/)
- [Understanding WCAG 2.2](https://www.w3.org/WAI/WCAG22/Understanding/)
- [WCAG 2.2 Techniques](https://www.w3.org/WAI/WCAG22/Techniques/)
- [WCAG 2 Overview](https://www.w3.org/WAI/standards-guidelines/wcag/)
- [W3C WCAG repository revision](https://github.com/w3c/wcag/tree/eea4dd0c7045fbca59a68b656fa37f30b7048fa6)
- [W3C WAI website repository revision](https://github.com/w3c/wai-website/tree/0ce2f18d0971f2de772d8e28dc513a39ce6b7e66)

The editorial source collection contains all 87 criterion sections (including the removed Parsing entry), their Understanding pages, the normative glossary and 433 currently indexed technique/failure documents. It also contains WCAG overview-family pages from the WAI repository, including available translation source files. Examples may reference remote assets. A compiled mirror would additionally require the sites' build dependencies, styles, images and linked resource collections. Refer to the published Recommendation for the normative edition and the W3C sites for rendered supporting documents. The manifest lists the file paths and Git blob identifiers used to verify the source collection.
